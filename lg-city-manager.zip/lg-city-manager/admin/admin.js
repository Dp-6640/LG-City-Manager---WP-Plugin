(function ($) {
    'use strict';

    var cfg       = window.lgCmAdmin || {};
    var locations = cfg.locations          ? cfg.locations.slice()          : [];
    var selective = cfg.selectiveLocations ? cfg.selectiveLocations.slice() : [];
    var services  = cfg.services           ? JSON.parse(JSON.stringify(cfg.services)) : [];

    /* ==========================================================
     * UTILS
     * ========================================================== */
    function toSlug(str) {
        return str.toLowerCase().trim().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    }

    function toLabel(slug) {
        return slug.replace(/-/g, ' ').replace(/\b\w/g, function (c) { return c.toUpperCase(); });
    }

    function showMsg($el, text, isError) {
        $el.text(text).css('color', isError ? '#b32d2e' : '#16a34a');
        setTimeout(function () { $el.text(''); }, 3500);
    }

    function showNotice(msg, type) {
        var cls = type === 'error' ? 'notice-error' : 'notice-success';
        var $n  = $('<div class="notice ' + cls + ' is-dismissible" style="margin-top:0;margin-bottom:12px"><p>' + msg + '</p></div>');
        $('.lg-cm-topbar').after($n);
        setTimeout(function () { $n.fadeOut(400, function () { $n.remove(); }); }, 4000);
    }

    /* ==========================================================
     * LOCATION LIST (full locations)
     * ========================================================== */
    function renderLocations() {
        var $list = $('#lg-cm-loc-list').empty();
        if (!locations.length) {
            $list.append('<p style="color:#9ca3af;font-size:13px;padding:8px 0">No locations added yet.</p>');
        }
        $.each(locations, function (i, slug) {
            var label = toLabel(slug);
            $list.append(
                '<div class="lg-cm-loc-item" data-slug="' + slug + '" data-type="location">' +
                '<span class="lg-cm-loc-dot"></span>' +
                '<span class="lg-cm-loc-name">' + label + '</span>' +
                '<span class="lg-cm-loc-slug">/' + slug + '/</span>' +
                '<div class="lg-cm-loc-actions">' +
                '<a href="' + cfg.siteUrl + '/locations/' + slug + '/" target="_blank" class="button button-small" title="Preview"><span class="dashicons dashicons-external" style="font-size:14px;line-height:26px"></span></a>' +
                '<button class="button button-small lg-cm-remove-loc" title="Remove"><span class="dashicons dashicons-trash" style="font-size:14px;line-height:26px;color:#b32d2e"></span></button>' +
                '</div></div>'
            );
        });
        $('#lg-cm-total-count').text(locations.length);
        $('#lg-cm-loc-badge').text(locations.length + ' location' + (locations.length === 1 ? '' : 's'));
    }

    $('#lg-cm-add-city').on('click', function () {
        var raw = $('#lg-cm-new-city').val().trim();
        if (!raw) return;
        var slug = toSlug(raw);
        if (locations.indexOf(slug) !== -1) { showNotice('This location already exists.', 'error'); return; }
        locations.push(slug);
        $('#lg-cm-new-city').val('');
        renderLocations();
    });

    $('#lg-cm-new-city').on('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); $('#lg-cm-add-city').trigger('click'); } });

    $(document).on('click', '.lg-cm-loc-item[data-type="location"] .lg-cm-remove-loc', function () {
        var slug = $(this).closest('.lg-cm-loc-item').data('slug');
        if (!confirm('Remove "' + toLabel(slug) + '" from locations?')) return;
        locations = locations.filter(function (s) { return s !== slug; });
        renderLocations();
    });

    $('#lg-cm-save-locations').on('click', function () {
        var $btn = $(this).prop('disabled', true).text('Saving…');
        $.post(cfg.ajaxUrl, { action: 'lg_cm_save_locations', nonce: cfg.nonce, locations: locations }, function (res) {
            $btn.prop('disabled', false).text('Save locations');
            if (res.success) showMsg($('#lg-cm-loc-msg'), '✓ Saved ' + res.data.count + ' locations.');
            else showMsg($('#lg-cm-loc-msg'), 'Error saving.', true);
        });
    });

    /* ==========================================================
     * SELECTIVE LOCATIONS
     * ========================================================== */
    function renderSelective() {
        var $list = $('#lg-cm-selective-list').empty();
        if (!selective.length) {
            $list.append('<p style="color:#9ca3af;font-size:13px;padding:8px 0">No selective locations added yet.</p>');
        }
        $.each(selective, function (i, slug) {
            $list.append(
                '<div class="lg-cm-loc-item" data-slug="' + slug + '" data-type="selective">' +
                '<span class="lg-cm-loc-dot" style="background:#f59e0b"></span>' +
                '<span class="lg-cm-loc-name">' + toLabel(slug) + '</span>' +
                '<span class="lg-cm-loc-slug">/' + slug + '/</span>' +
                '<div class="lg-cm-loc-actions">' +
                '<button class="button button-small lg-cm-remove-loc" title="Remove"><span class="dashicons dashicons-trash" style="font-size:14px;line-height:26px;color:#b32d2e"></span></button>' +
                '</div></div>'
            );
        });
        $('#lg-cm-selective-count').text(selective.length);
        $('#lg-cm-sel-badge').text(selective.length + ' location' + (selective.length === 1 ? '' : 's'));
    }

    $('#lg-cm-add-selective').on('click', function () {
        var raw = $('#lg-cm-new-selective').val().trim();
        if (!raw) return;
        var slug = toSlug(raw);
        if (selective.indexOf(slug) !== -1) { showNotice('Already in selective list.', 'error'); return; }
        selective.push(slug);
        $('#lg-cm-new-selective').val('');
        renderSelective();
    });

    $('#lg-cm-new-selective').on('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); $('#lg-cm-add-selective').trigger('click'); } });

    $(document).on('click', '.lg-cm-loc-item[data-type="selective"] .lg-cm-remove-loc', function () {
        var slug = $(this).closest('.lg-cm-loc-item').data('slug');
        if (!confirm('Remove "' + toLabel(slug) + '" from selective list?')) return;
        selective = selective.filter(function (s) { return s !== slug; });
        renderSelective();
    });

    $('#lg-cm-save-selective').on('click', function () {
        var $btn = $(this).prop('disabled', true).text('Saving…');
        $.post(cfg.ajaxUrl, { action: 'lg_cm_save_selective', nonce: cfg.nonce, locations: selective }, function (res) {
            $btn.prop('disabled', false).text('Save selective locations');
            if (res.success) showMsg($('#lg-cm-sel-msg'), '✓ Saved ' + res.data.count + ' selective locations.');
            else showMsg($('#lg-cm-sel-msg'), 'Error saving.', true);
        });
    });

    /* ==========================================================
     * SERVICES MANAGER
     * ========================================================== */
    function collectServices() {
        var result = [];
        $('#lg-cm-services-list .lg-cm-service-block').each(function () {
            var $block = $(this);
            var slug   = $block.find('.lg-cm-service-slug').val().trim();
            var label  = $block.find('.lg-cm-service-label').val().trim();
            if (!slug) return;
            var subs = [];
            $block.find('.lg-cm-sub-row').each(function () {
                var $r = $(this);
                var subSlug = $r.find('.lg-cm-sub-slug').val().trim();
                if (!subSlug) return;
                subs.push({
                    slug:         subSlug,
                    label:        $r.find('.lg-cm-sub-label').val().trim(),
                    toronto_slug: $r.find('.lg-cm-sub-toronto').val().trim(),
                    other_slug:   $r.find('.lg-cm-sub-other').val().trim(),
                    generic_slug: $r.find('.lg-cm-sub-generic').val().trim(),
                });
            });
            result.push({ slug: slug, label: label, subs: subs });
        });
        return result;
    }

    // Add new service block
    $('#lg-cm-add-service').on('click', function () {
        var name = prompt('Service name (e.g. Generators):');
        if (!name) return;
        var slug  = toSlug(name);
        var idx   = $('#lg-cm-services-list .lg-cm-service-block').length;
        var block = buildServiceBlockHTML(idx, { slug: slug, label: name, subs: [] });
        $('#lg-cm-services-list').append(block);
    });

    // Remove service block
    $(document).on('click', '.lg-cm-remove-service', function () {
        if (!confirm('Remove this service and all its sub-services?')) return;
        $(this).closest('.lg-cm-service-block').remove();
    });

    // Toggle sub-services visibility
    $(document).on('click', '.lg-cm-toggle-subs', function () {
        var $wrap = $(this).closest('.lg-cm-service-block').find('.lg-cm-subs-wrap');
        $wrap.toggle();
        var count = $wrap.find('.lg-cm-sub-row').length;
        $(this).text($wrap.is(':visible') ? '▾ Sub-services (' + count + ')' : '▸ Sub-services (' + count + ')');
    });

    // Add sub-service row
    $(document).on('click', '.lg-cm-add-sub', function () {
        var $row = $(
            '<div class="lg-cm-sub-row">' +
            '<input type="text" class="lg-cm-sub-slug"    placeholder="e.g. installation" />' +
            '<input type="text" class="lg-cm-sub-label"   placeholder="Label" />' +
            '<input type="text" class="lg-cm-sub-toronto" placeholder="toronto-slug (blank = same)" />' +
            '<input type="text" class="lg-cm-sub-other"   placeholder="other-slug (blank = same)" />' +
            '<input type="text" class="lg-cm-sub-generic" placeholder="generic-slug (blank = same)" />' +
            '<button class="button button-small lg-cm-remove-sub" style="flex:0 0 32px;padding:0;color:#b32d2e">✕</button>' +
            '</div>'
        );
        $(this).prev('.lg-cm-subs-list').append($row);
        updateSubCount($(this).closest('.lg-cm-service-block'));
    });

    // Remove sub row
    $(document).on('click', '.lg-cm-remove-sub', function () {
        var $block = $(this).closest('.lg-cm-service-block');
        $(this).closest('.lg-cm-sub-row').remove();
        updateSubCount($block);
    });

    // Auto-generate slug from label for service name
    $(document).on('input', '.lg-cm-service-label', function () {
        var slug = toSlug($(this).val());
        $(this).siblings('.lg-cm-service-slug').val(slug);
        $(this).siblings('.lg-cm-service-slug-display').text('/' + slug + '/');
    });

    function updateSubCount($block) {
        var count = $block.find('.lg-cm-sub-row').length;
        $block.find('.lg-cm-toggle-subs').text('▾ Sub-services (' + count + ')');
    }

    function buildServiceBlockHTML(idx, service) {
        var subs = (service.subs || []).map(function (sub) {
            return '<div class="lg-cm-sub-row">' +
                '<input type="text" class="lg-cm-sub-slug"    value="' + (sub.slug         || '') + '" placeholder="e.g. installation" />' +
                '<input type="text" class="lg-cm-sub-label"   value="' + (sub.label        || '') + '" placeholder="Label" />' +
                '<input type="text" class="lg-cm-sub-toronto" value="' + (sub.toronto_slug || '') + '" placeholder="toronto-slug" />' +
                '<input type="text" class="lg-cm-sub-other"   value="' + (sub.other_slug   || '') + '" placeholder="other-slug" />' +
                '<input type="text" class="lg-cm-sub-generic" value="' + (sub.generic_slug || '') + '" placeholder="generic-slug" />' +
                '<button class="button button-small lg-cm-remove-sub" style="flex:0 0 32px;padding:0;color:#b32d2e">✕</button>' +
                '</div>';
        }).join('');

        return '<div class="lg-cm-service-block" data-index="' + idx + '">' +
            '<div class="lg-cm-service-header">' +
            '<div class="lg-cm-service-header-left">' +
            '<span class="dashicons dashicons-menu-alt2 lg-cm-drag-handle"></span>' +
            '<div>' +
            '<input type="text" class="lg-cm-service-label" value="' + service.label + '" placeholder="Service name" />' +
            '<code class="lg-cm-service-slug-display">/' + service.slug + '/</code>' +
            '<input type="hidden" class="lg-cm-service-slug" value="' + service.slug + '" />' +
            '</div></div>' +
            '<div class="lg-cm-service-header-right">' +
            '<button class="button button-small lg-cm-toggle-subs">▾ Sub-services (' + (service.subs || []).length + ')</button>' +
            '<button class="button button-small lg-cm-remove-service lg-cm-btn-danger-sm">Remove</button>' +
            '</div></div>' +
            '<div class="lg-cm-subs-wrap">' +
            '<div class="lg-cm-subs-header">' +
            '<span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">SUB SLUG</span>' +
            '<span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">LABEL</span>' +
            '<span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">TORONTO SLUG</span>' +
            '<span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">OTHER SLUG</span>' +
            '<span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">GENERIC SLUG</span>' +
            '<span style="flex:0 0 32px"></span></div>' +
            '<div class="lg-cm-subs-list">' + subs + '</div>' +
            '<button class="button button-small lg-cm-add-sub" style="margin-top:8px">+ Add sub-service</button>' +
            '</div></div>';
    }

    // Save services
    $('#lg-cm-save-services').on('click', function () {
        var $btn  = $(this).prop('disabled', true).text('Saving…');
        var data  = collectServices();
        $.post(cfg.ajaxUrl, {
            action:   'lg_cm_save_services',
            nonce:    cfg.nonce,
            services: data,
        }, function (res) {
            $btn.prop('disabled', false).text('Save all services');
            if (res.success) {
                showMsg($('#lg-cm-services-msg'), '✓ Saved ' + res.data.services.length + ' services (' + res.data.validPaths.length + ' valid paths).');
                showNotice('Services saved. Valid service paths updated.', 'success');
            } else {
                showMsg($('#lg-cm-services-msg'), 'Error saving services.', true);
            }
        });
    });

    /* ==========================================================
     * SETTINGS
     * ========================================================== */
    $('#lg-cm-settings-form').on('submit', function (e) {
        e.preventDefault();
        var $btn = $(this).find('[type=submit]').prop('disabled', true).text('Saving…');
        var data = { action: 'lg_cm_save_settings', nonce: cfg.nonce };
        $(this).find('input[type=checkbox]').each(function () {
            if ($(this).is(':checked')) data[$(this).attr('name')] = 1;
        });
        $.post(cfg.ajaxUrl, data, function (res) {
            $btn.prop('disabled', false).text('Save settings');
            if (res.success) showMsg($('#lg-cm-settings-msg'), '✓ Settings saved.');
            else showMsg($('#lg-cm-settings-msg'), 'Error.', true);
        });
    });

    /* ==========================================================
     * INIT
     * ========================================================== */
    $(function () {
        cfg.siteUrl = cfg.siteUrl || window.location.origin;
        renderLocations();
        renderSelective();
        // Hide all sub-wrap initially for cleaner UI
        $('.lg-cm-subs-wrap').hide();
    });

})(jQuery);
