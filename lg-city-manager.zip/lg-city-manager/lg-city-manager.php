<?php
/**
 * Plugin Name: LG City Manager
 * Plugin URI:  https://lghomecomfort.ca
 * Description: Manages city-based location detection, menu URL rewriting, 404 redirects, and city persistence. Fully dashboard-driven — no hardcoding needed.
 * Version:     2.1.0
 * Author:      LG Home Comfort
 * License:     GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LG_CM_VERSION', '2.1.0' );
define( 'LG_CM_PATH', plugin_dir_path( __FILE__ ) );
define( 'LG_CM_URL',  plugin_dir_url( __FILE__ ) );


/* =============================================================
 * ACTIVATION — seed defaults
 * ============================================================= */
register_activation_hook( __FILE__, 'lg_cm_activate' );
function lg_cm_activate() {

    if ( ! get_option( 'lg_cm_locations' ) ) {
        update_option( 'lg_cm_locations', [
            'toronto', 'hamilton', 'oakville', 'mississauga', 'brampton', 'burlington',
        ] );
    }

    if ( ! get_option( 'lg_cm_selective_locations' ) ) {
        update_option( 'lg_cm_selective_locations', [
            'ajax', 'bradford', 'burlington', 'georgetown', 'newmarket', 'oshawa',
            'richmond-hill', 'st-catharines', 'london', 'whitby', 'smithville',
            'bowmanville', 'grimsby', 'keswick', 'lindsay', 'orangeville',
            'peterborough', 'stouffville', 'uxbridge', 'welland', 'alliston',
            'belleville', 'bolton', 'brockville', 'collingwood', 'kingston',
            'midland', 'north-bay', 'sudbury', 'niagara', 'king-city',
            'orillia', 'parry-sound-muskoka', 'durham',
        ] );
    }

    // Default services — each service has parent + sub-services
    if ( ! get_option( 'lg_cm_services' ) ) {
        update_option( 'lg_cm_services', [
            [
                'slug'  => 'heat-pumps',
                'label' => 'Heat Pumps',
                'subs'  => [
                    [ 'slug' => 'installation', 'label' => 'Installation', 'toronto_slug' => '', 'other_slug' => '' ],
                    [ 'slug' => 'repair',       'label' => 'Repair',       'toronto_slug' => '', 'other_slug' => '' ],
                    [ 'slug' => 'maintenance',  'label' => 'Maintenance',  'toronto_slug' => '', 'other_slug' => '' ],
                ],
            ],
            [
                'slug'  => 'furnace',
                'label' => 'Furnace',
                'subs'  => [
                    [ 'slug' => 'installation', 'label' => 'Installation', 'toronto_slug' => '', 'other_slug' => '' ],
                    [ 'slug' => 'repair',       'label' => 'Repair',       'toronto_slug' => '', 'other_slug' => '' ],
                    [ 'slug' => 'maintenance',  'label' => 'Maintenance',  'toronto_slug' => '', 'other_slug' => '' ],
                ],
            ],
            [
                'slug'  => 'air-conditioning',
                'label' => 'Air Conditioning',
                'subs'  => [
                    [ 'slug' => 'installation', 'label' => 'Installation', 'toronto_slug' => 'ac-installation', 'other_slug' => '' ],
                    [ 'slug' => 'repair',       'label' => 'Repair',       'toronto_slug' => '', 'other_slug' => '' ],
                    [ 'slug' => 'maintenance',  'label' => 'Maintenance',  'toronto_slug' => '', 'other_slug' => '' ],
                ],
            ],
            [
                'slug'  => 'water-heaters',
                'label' => 'Water Heaters',
                'subs'  => [
                    [ 'slug' => 'installation', 'label' => 'Installation', 'toronto_slug' => '', 'other_slug' => '' ],
                    [ 'slug' => 'repair',       'label' => 'Repair',       'toronto_slug' => '', 'other_slug' => '' ],
                    [ 'slug' => 'maintenance',  'label' => 'Maintenance',  'toronto_slug' => '', 'other_slug' => '' ],
                ],
            ],
            [
                'slug'  => 'air-purification',
                'label' => 'Air Purification',
                'subs'  => [
                    [ 'slug' => 'humidifier',   'label' => 'Humidifier',       'toronto_slug' => '',              'other_slug' => 'humidifier-installation' ],
                    [ 'slug' => 'hepa-filter',  'label' => 'HEPA Filter',      'toronto_slug' => '',              'other_slug' => 'hepa-filter-installation' ],
                    [ 'slug' => 'air-purifier', 'label' => 'Air Purifier',     'toronto_slug' => 'air-filter',    'other_slug' => 'air-purifier-installation' ],
                ],
            ],
            [
                'slug'  => 'water-purification',
                'label' => 'Water Purification',
                'subs'  => [
                    [ 'slug' => 'water-softener',           'label' => 'Water Softener',    'toronto_slug' => '', 'other_slug' => '' ],
                    [ 'slug' => 'reverse-osmosis',          'label' => 'Reverse Osmosis',   'toronto_slug' => '', 'other_slug' => '',    'generic_slug' => 'reverse-osmosis-system' ],
                    [ 'slug' => 'water-carbon-filter',      'label' => 'Water Carbon Filter','toronto_slug' => '', 'other_slug' => '' ],
                ],
            ],
        ] );
    }

    if ( ! get_option( 'lg_cm_settings' ) ) {
        update_option( 'lg_cm_settings', [
            'cookie_fallback'  => 1,
            'generic_fallback' => 1,
            'show_city_in_btn' => 1,
            'debug_mode'       => 0,
        ] );
    }
}


/* =============================================================
 * DATA HELPERS
 * ============================================================= */
function lg_cm_get_locations() {
    $l = get_option( 'lg_cm_locations', [] );
    return is_array( $l ) ? $l : [];
}

function lg_cm_get_selective_locations() {
    $l = get_option( 'lg_cm_selective_locations', [] );
    return is_array( $l ) ? $l : [];
}

function lg_cm_get_services() {
    $s = get_option( 'lg_cm_services', [] );
    return is_array( $s ) ? $s : [];
}

function lg_cm_get_settings() {
    $defaults = [ 'cookie_fallback' => 1, 'generic_fallback' => 1, 'show_city_in_btn' => 1, 'debug_mode' => 0 ];
    return wp_parse_args( get_option( 'lg_cm_settings', [] ), $defaults );
}

function lg_cm_label( $slug ) {
    return ucwords( str_replace( '-', ' ', $slug ) );
}

/**
 * Build flat list of valid service paths for 404 redirect + JS
 * e.g. [ "heat-pumps/installation", "air-purification/humidifier", ... ]
 */
function lg_cm_get_valid_service_paths() {
    $services = lg_cm_get_services();
    $paths    = [];
    foreach ( $services as $service ) {
        $parent = $service['slug'];
        if ( empty( $service['subs'] ) ) continue;
        foreach ( $service['subs'] as $sub ) {
            // Generic slug for this sub (may differ for generic page)
            $generic_slug = ! empty( $sub['generic_slug'] ) ? $sub['generic_slug'] : $sub['slug'];
            $paths[] = $parent . '/' . $generic_slug;
            // Also add base slug if different from generic
            if ( $generic_slug !== $sub['slug'] ) {
                $paths[] = $parent . '/' . $sub['slug'];
            }
        }
    }
    return array_values( array_unique( $paths ) );
}

/**
 * Build URL maps from services (replaces hardcoded map functions)
 */
function lg_cm_build_url_maps() {
    $services = lg_cm_get_services();
    $maps     = [];

    foreach ( $services as $service ) {
        $parent = $service['slug'];

        // Parent map entry
        $maps[ $parent ] = [
            'toronto' => '/' . $parent . '/',
            'other'   => '/' . $parent . '/',
        ];

        if ( empty( $service['subs'] ) ) continue;

        foreach ( $service['subs'] as $sub ) {
            $base_slug    = $sub['slug'];
            $generic_slug = ! empty( $sub['generic_slug'] ) ? $sub['generic_slug'] : $base_slug;
            $toronto_slug = ! empty( $sub['toronto_slug'] ) ? $sub['toronto_slug'] : $base_slug;
            $other_slug   = ! empty( $sub['other_slug'] )   ? $sub['other_slug']   : $base_slug;

            // Use sub slug as key (may conflict if same sub in multiple parents — prefix with parent)
            $key = $parent . '__' . $base_slug;

            $maps[ $key ] = [
                'parent'  => $parent,
                'sub'     => $base_slug,
                'generic' => '/' . $parent . '/' . $generic_slug . '/',
                'toronto' => '/' . $parent . '/' . $toronto_slug . '/',
                'other'   => '/' . $parent . '/' . $other_slug   . '/',
            ];
        }
    }

    return $maps;
}


/* =============================================================
 * 1. DETECT CURRENT CITY SLUG
 * ============================================================= */
function lg_get_current_city_slug() {

    // Admin override takes priority
    if ( ! empty( $_COOKIE['lg_city_admin_override'] ) ) {
        return sanitize_title( $_COOKIE['lg_city_admin_override'] );
    }

    $settings = lg_cm_get_settings();
    $path     = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );
    $segments = explode( '/', $path );

    if ( isset( $segments[0], $segments[1] ) && $segments[0] === 'locations' && ! empty( $segments[1] ) ) {
        return sanitize_title( $segments[1] );
    }

    if ( $settings['cookie_fallback'] && ! empty( $_COOKIE['lg_city'] ) ) {
        return sanitize_title( $_COOKIE['lg_city'] );
    }

    return null;
}


/* =============================================================
 * 2. CHECK IF CITY PAGE EXISTS
 * ============================================================= */
function lg_city_page_exists( $city_url ) {
    $settings = lg_cm_get_settings();
    if ( ! $settings['generic_fallback'] ) return true;
    $post_id = url_to_postid( home_url( $city_url ) );
    return $post_id > 0;
}


/* =============================================================
 * 3. BODY CLASS
 * ============================================================= */
add_filter( 'body_class', function( $classes ) {
    if ( lg_get_current_city_slug() ) $classes[] = 'locations';
    return $classes;
} );


/* =============================================================
 * 4. MENU URL REWRITING (fully dynamic from DB)
 * ============================================================= */
add_filter( 'wp_nav_menu_objects', function( $items ) {

    $city = lg_get_current_city_slug();
    $maps = lg_cm_build_url_maps();
    $services = lg_cm_get_services();

    foreach ( $items as $item ) {
        $item_url = rtrim( $item->url, '/' );

        foreach ( $maps as $key => $rule ) {

            // Parent-level menu item (no 'sub' key)
            if ( ! isset( $rule['sub'] ) ) {
                if ( ! $city ) continue;
                $parent    = $rule['toronto'] ?? ( '/' . $key . '/' );
                $city_url  = '/locations/' . $city . $parent;
                if ( str_ends_with( $item_url, '/' . $key ) || rtrim( $parent, '/' ) === $item_url ) {
                    $item->url = lg_city_page_exists( $city_url ) ? $city_url : $parent;
                    break;
                }
                continue;
            }

            // Sub-level menu item
            $generic = rtrim( $rule['generic'], '/' );
            if ( strpos( $item_url, $generic ) === false ) continue;

            if ( ! $city ) {
                $item->url = $rule['generic'];
                break;
            }

            $path     = ( $city === 'toronto' ) ? $rule['toronto'] : $rule['other'];
            $city_url = '/locations/' . $city . $path;
            $item->url = lg_city_page_exists( $city_url ) ? $city_url : $rule['generic'];
            break;
        }
    }

    return $items;
}, 20 );


/* =============================================================
 * 5. 404 REDIRECT (dynamic from DB)
 * ============================================================= */
add_action( 'template_redirect', 'lg_redirect_location_404' );
function lg_redirect_location_404() {
    if ( ! is_404() ) return;

    $valid_services = lg_cm_get_valid_service_paths();
    $request_uri    = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );
    $segments       = explode( '/', $request_uri );

    if ( count( $segments ) < 3 || $segments[0] !== 'locations' ) return;

    $service_segments = array_slice( $segments, 2 );
    $service_path     = implode( '/', $service_segments );

    // Exact match
    if ( in_array( $service_path, $valid_services ) ) {
        wp_redirect( home_url( '/' . $service_path . '/' ), 301 );
        exit;
    }

    // Normalize last segment (remove -installation/-repair/-maintenance suffix)
    if ( isset( $service_segments[1] ) ) {
        $service_segments[1] = preg_replace( '/-(installation|repair|maintenance)$/', '', $service_segments[1] );
    }
    $normalized = implode( '/', $service_segments );

    if ( in_array( $normalized, $valid_services ) ) {
        wp_redirect( home_url( '/' . $normalized . '/' ), 301 );
        exit;
    }

    // Special: reverse-osmosis variants → system page
    if ( strpos( $service_path, 'water-purification/reverse-osmosis' ) === 0 ) {
        wp_redirect( home_url( '/water-purification/reverse-osmosis-system/' ), 301 );
        exit;
    }

    // Fallback — redirect to parent service
    if ( ! empty( $service_segments[0] ) ) {
        $parent_url = home_url( '/' . $service_segments[0] . '/' );
        $post_id    = url_to_postid( $parent_url );
        if ( $post_id > 0 ) {
            wp_redirect( $parent_url, 301 );
            exit;
        }
    }
}


/* =============================================================
 * 6. ENQUEUE FRONTEND SCRIPT
 * ============================================================= */
add_action( 'wp_enqueue_scripts', function() {
    $settings = lg_cm_get_settings();
    wp_enqueue_script( 'lg-city-manager', LG_CM_URL . 'js/city-manager.js', [], LG_CM_VERSION, true );
    wp_localize_script( 'lg-city-manager', 'lgCityManager', [
        'showCityInBtn'      => (int) $settings['show_city_in_btn'],
        'debugMode'          => (int) $settings['debug_mode'],
        'validServices'      => lg_cm_get_valid_service_paths(),
        'selectiveLocations' => lg_cm_get_selective_locations(),
        'locations'          => lg_cm_get_locations(),
    ] );
} );


/* =============================================================
 * 7. ADMIN MENU
 * ============================================================= */
add_action( 'admin_menu', function() {
    add_menu_page( 'LG City Manager', 'City Manager', 'manage_options', 'lg-city-manager', 'lg_cm_render_dashboard', 'dashicons-location-alt', 80 );
} );

/* =============================================================
 * ADMIN TOOLBAR — Location Override
 * ============================================================= */
add_action( 'admin_bar_menu', 'lg_cm_toolbar_node', 999 );
function lg_cm_toolbar_node( $wp_admin_bar ) {
    if ( ! current_user_can( 'manage_options' ) ) return;

    $locations      = lg_cm_get_locations();
    $admin_override = isset( $_COOKIE['lg_city_admin_override'] ) ? sanitize_title( $_COOKIE['lg_city_admin_override'] ) : '';
    $visitor_city   = isset( $_COOKIE['lg_city'] )               ? sanitize_title( $_COOKIE['lg_city'] )               : '';

    // Active label for toolbar button
    if ( $admin_override ) {
        $active_label = '📍 ' . lg_cm_label( $admin_override ) . ' (override)';
        $title_color  = '#f59e0b';
    } elseif ( $visitor_city ) {
        $active_label = '📍 ' . lg_cm_label( $visitor_city );
        $title_color  = '#60a5fa';
    } else {
        $active_label = '📍 No city set';
        $title_color  = '#9ca3af';
    }

    // Parent node
    $wp_admin_bar->add_node( [
        'id'    => 'lg-cm-toolbar',
        'title' => '<span style="color:' . $title_color . ';font-weight:600">' . esc_html( $active_label ) . '</span>',
        'href'  => '#',
        'meta'  => [ 'class' => 'lg-cm-toolbar-node' ],
    ] );

    // Section label — Override
    $wp_admin_bar->add_node( [
        'id'     => 'lg-cm-override-label',
        'parent' => 'lg-cm-toolbar',
        'title'  => '<span style="font-size:10px;color:#9ca3af;text-transform:uppercase;letter-spacing:.05em;padding:4px 12px;display:block">Set Override City</span>',
        'href'   => '#',
    ] );

    // City options as sub-nodes
    foreach ( $locations as $slug ) {
        $label    = lg_cm_label( $slug );
        $is_active = ( $admin_override === $slug );
        $wp_admin_bar->add_node( [
            'id'     => 'lg-cm-city-' . $slug,
            'parent' => 'lg-cm-toolbar',
            'title'  => ( $is_active ? '✓ ' : '　' ) . esc_html( $label ),
            'href'   => '#',
            'meta'   => [
                'class'    => 'lg-cm-set-override' . ( $is_active ? ' lg-cm-active-city' : '' ),
                'data-city'=> $slug,
                'onclick'  => 'lgCmSetOverride("' . esc_js( $slug ) . '"); return false;',
            ],
        ] );
    }

    // Divider + actions
    $wp_admin_bar->add_node( [
        'id'     => 'lg-cm-divider',
        'parent' => 'lg-cm-toolbar',
        'title'  => '<span style="display:block;border-top:1px solid #3c434a;margin:4px 0"></span>',
        'href'   => '#',
    ] );

    if ( $admin_override ) {
        $wp_admin_bar->add_node( [
            'id'     => 'lg-cm-clear-override',
            'parent' => 'lg-cm-toolbar',
            'title'  => '✕ Clear override',
            'href'   => '#',
            'meta'   => [ 'onclick' => 'lgCmClearOverride(); return false;', 'class' => 'lg-cm-toolbar-danger' ],
        ] );
    }

    if ( $visitor_city ) {
        $wp_admin_bar->add_node( [
            'id'     => 'lg-cm-clear-cookie',
            'parent' => 'lg-cm-toolbar',
            'title'  => '🗑 Clear visitor cookie (' . esc_html( lg_cm_label( $visitor_city ) ) . ')',
            'href'   => '#',
            'meta'   => [ 'onclick' => 'lgCmClearCookie(); return false;', 'class' => 'lg-cm-toolbar-danger' ],
        ] );
    }

    // Link to dashboard
    $wp_admin_bar->add_node( [
        'id'     => 'lg-cm-go-dashboard',
        'parent' => 'lg-cm-toolbar',
        'title'  => '⚙ City Manager settings',
        'href'   => admin_url( 'admin.php?page=lg-city-manager' ),
    ] );
}

// Enqueue toolbar JS + CSS on both frontend and admin
add_action( 'wp_enqueue_scripts',    'lg_cm_toolbar_assets' );
add_action( 'admin_enqueue_scripts', 'lg_cm_toolbar_assets' );
function lg_cm_toolbar_assets() {
    if ( ! is_admin_bar_showing() || ! current_user_can( 'manage_options' ) ) return;
    wp_add_inline_style( 'admin-bar', '
        #wp-admin-bar-lg-cm-toolbar > .ab-item { color:#f0f0f0 !important; }
        #wp-admin-bar-lg-cm-toolbar .ab-submenu { min-width:220px !important; }
        #wp-admin-bar-lg-cm-clear-override > .ab-item,
        #wp-admin-bar-lg-cm-clear-cookie > .ab-item { color:#f87171 !important; }
        #wp-admin-bar-lg-cm-override-label > .ab-item,
        #wp-admin-bar-lg-cm-divider > .ab-item { pointer-events:none; }
        #wp-admin-bar-lg-cm-go-dashboard > .ab-item { color:#60a5fa !important; }
        .lg-cm-active-city > .ab-item { color:#4ade80 !important; font-weight:600; }
    ' );
    wp_add_inline_script( 'jquery-core', '
        function lgCmSetOverride(city) {
            document.cookie = "lg_city_admin_override=" + city + ";path=/;max-age=86400;SameSite=Lax";
            location.reload();
        }
        function lgCmClearOverride() {
            document.cookie = "lg_city_admin_override=;path=/;max-age=0";
            location.reload();
        }
        function lgCmClearCookie() {
            document.cookie = "lg_city=;path=/;max-age=0";
            try { localStorage.removeItem("lg_city"); } catch(e) {}
            location.reload();
        }
    ' );
}


add_action( 'admin_enqueue_scripts', function( $hook ) {
    if ( $hook !== 'toplevel_page_lg-city-manager' ) return;
    wp_enqueue_style(  'lg-cm-admin', LG_CM_URL . 'admin/admin.css', [], LG_CM_VERSION );
    wp_enqueue_script( 'lg-cm-admin', LG_CM_URL . 'admin/admin.js', [ 'jquery' ], LG_CM_VERSION, true );
    wp_localize_script( 'lg-cm-admin', 'lgCmAdmin', [
        'ajaxUrl'            => admin_url( 'admin-ajax.php' ),
        'nonce'              => wp_create_nonce( 'lg_cm_nonce' ),
        'siteUrl'            => home_url(),
        'locations'          => lg_cm_get_locations(),
        'selectiveLocations' => lg_cm_get_selective_locations(),
        'services'           => lg_cm_get_services(),
        'settings'           => lg_cm_get_settings(),
        'activeCookieCity'   => isset( $_COOKIE['lg_city'] )               ? sanitize_title( $_COOKIE['lg_city'] )               : '',
        'adminOverride'      => isset( $_COOKIE['lg_city_admin_override'] ) ? sanitize_title( $_COOKIE['lg_city_admin_override'] ) : '',
    ] );
} );


/* =============================================================
 * 8. AJAX HANDLERS
 * ============================================================= */

// Save locations
add_action( 'wp_ajax_lg_cm_save_locations', function() {
    check_ajax_referer( 'lg_cm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
    $raw  = isset( $_POST['locations'] ) ? (array) $_POST['locations'] : [];
    $locs = array_values( array_filter( array_map( 'sanitize_title', $raw ) ) );
    update_option( 'lg_cm_locations', $locs );
    wp_send_json_success( [ 'locations' => $locs, 'count' => count( $locs ) ] );
} );

// Save selective locations
add_action( 'wp_ajax_lg_cm_save_selective', function() {
    check_ajax_referer( 'lg_cm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
    $raw  = isset( $_POST['locations'] ) ? (array) $_POST['locations'] : [];
    $locs = array_values( array_filter( array_map( 'sanitize_title', $raw ) ) );
    update_option( 'lg_cm_selective_locations', $locs );
    wp_send_json_success( [ 'locations' => $locs, 'count' => count( $locs ) ] );
} );

// Save services
add_action( 'wp_ajax_lg_cm_save_services', function() {
    check_ajax_referer( 'lg_cm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

    $raw = isset( $_POST['services'] ) ? $_POST['services'] : [];
    if ( ! is_array( $raw ) ) wp_send_json_error( 'Invalid data' );

    $clean = [];
    foreach ( $raw as $service ) {
        $parent_slug  = sanitize_title( $service['slug'] ?? '' );
        $parent_label = sanitize_text_field( $service['label'] ?? '' );
        if ( ! $parent_slug ) continue;
        $subs = [];
        if ( ! empty( $service['subs'] ) && is_array( $service['subs'] ) ) {
            foreach ( $service['subs'] as $sub ) {
                $sub_slug = sanitize_title( $sub['slug'] ?? '' );
                if ( ! $sub_slug ) continue;
                $subs[] = [
                    'slug'         => $sub_slug,
                    'label'        => sanitize_text_field( $sub['label']        ?? '' ),
                    'toronto_slug' => sanitize_title( $sub['toronto_slug'] ?? '' ),
                    'other_slug'   => sanitize_title( $sub['other_slug']   ?? '' ),
                    'generic_slug' => sanitize_title( $sub['generic_slug'] ?? '' ),
                ];
            }
        }
        $clean[] = [ 'slug' => $parent_slug, 'label' => $parent_label, 'subs' => $subs ];
    }

    update_option( 'lg_cm_services', $clean );
    wp_send_json_success( [ 'services' => $clean, 'validPaths' => lg_cm_get_valid_service_paths() ] );
} );

// Save settings
add_action( 'wp_ajax_lg_cm_save_settings', function() {
    check_ajax_referer( 'lg_cm_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );
    $allowed = [ 'cookie_fallback', 'generic_fallback', 'show_city_in_btn', 'debug_mode' ];
    $current = lg_cm_get_settings();
    foreach ( $allowed as $key ) $current[ $key ] = isset( $_POST[ $key ] ) ? 1 : 0;
    update_option( 'lg_cm_settings', $current );
    wp_send_json_success( $current );
} );


/* =============================================================
 * 9. DASHBOARD HTML
 * ============================================================= */
function lg_cm_render_dashboard() {
    $locations          = lg_cm_get_locations();
    $selective          = lg_cm_get_selective_locations();
    $services           = lg_cm_get_services();
    $settings           = lg_cm_get_settings();
    $active_cookie      = isset( $_COOKIE['lg_city'] )               ? sanitize_title( $_COOKIE['lg_city'] )               : '';
    $admin_override     = isset( $_COOKIE['lg_city_admin_override'] ) ? sanitize_title( $_COOKIE['lg_city_admin_override'] ) : '';
    $valid_paths        = lg_cm_get_valid_service_paths();
    ?>
    <div class="wrap lg-cm-wrap">

        <!-- Top bar -->
        <div class="lg-cm-topbar">
            <div class="lg-cm-title">
                <span class="dashicons dashicons-location-alt lg-cm-icon"></span>
                <div>
                    <h1>LG City Manager</h1>
                    <span class="lg-cm-version">v<?php echo LG_CM_VERSION; ?></span>
                </div>
            </div>
            <div class="lg-cm-topbar-right">
                <span class="lg-cm-status-dot"></span>
                <span>Plugin active</span>
            </div>
        </div>

        <!-- Stats -->
        <div class="lg-cm-stats">
            <div class="lg-cm-stat">
                <div class="lg-cm-stat-label">Total locations</div>
                <div class="lg-cm-stat-value" id="lg-cm-total-count"><?php echo count( $locations ); ?></div>
                <div class="lg-cm-stat-sub">Full city pages</div>
            </div>
            <div class="lg-cm-stat">
                <div class="lg-cm-stat-label">Selective locations</div>
                <div class="lg-cm-stat-value" id="lg-cm-selective-count"><?php echo count( $selective ); ?></div>
                <div class="lg-cm-stat-sub">JS redirect only</div>
            </div>
            <div class="lg-cm-stat">
                <div class="lg-cm-stat-label">Services configured</div>
                <div class="lg-cm-stat-value"><?php echo count( $services ); ?></div>
                <div class="lg-cm-stat-sub"><?php echo count( $valid_paths ); ?> valid sub-paths</div>
            </div>
            <div class="lg-cm-stat">
                <div class="lg-cm-stat-label">Your browser city</div>
                <div class="lg-cm-stat-value lg-cm-stat-city">
                    <?php echo $active_cookie ? esc_html( lg_cm_label( $active_cookie ) ) : '<span class="lg-cm-muted">None</span>'; ?>
                </div>
                <div class="lg-cm-stat-sub">
                    <?php if ( $admin_override ) : ?>
                        Override: <strong style="color:#f59e0b"><?php echo esc_html( lg_cm_label( $admin_override ) ); ?></strong>
                    <?php else : ?>
                        From <code>lg_city</code> cookie
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="lg-cm-info-box" style="margin-bottom:1rem">
            <span class="dashicons dashicons-info-outline"></span>
            <span>Use the <strong>📍 City</strong> menu in the <strong>WordPress admin toolbar</strong> (top bar) to set or clear your location override — on any page, frontend or admin.</span>
        </div>

        <!-- Services Manager -->
        <div class="lg-cm-panel">
            <div class="lg-cm-panel-header">
                <div>
                    <h2>Services &amp; sub-services</h2>
                    <p>Add, edit or remove services and their sub-pages. Changes are saved to the database — no code edits needed.</p>
                </div>
                <button class="button button-primary" id="lg-cm-add-service">+ Add service</button>
            </div>

            <div id="lg-cm-services-list">
                <?php foreach ( $services as $si => $service ) : ?>
                    <?php echo lg_cm_service_block_html( $si, $service ); ?>
                <?php endforeach; ?>
            </div>

            <div class="lg-cm-panel-footer">
                <button class="button button-primary" id="lg-cm-save-services">Save all services</button>
                <span class="lg-cm-save-msg" id="lg-cm-services-msg"></span>
            </div>
        </div>

        <!-- Location Management -->
        <div class="lg-cm-panel">
            <div class="lg-cm-panel-header">
                <div>
                    <h2>Location management</h2>
                    <p>Cities with full dedicated location pages</p>
                </div>
                <span class="lg-cm-badge lg-cm-badge-info" id="lg-cm-loc-badge"><?php echo count( $locations ); ?> locations</span>
            </div>
            <div class="lg-cm-add-row">
                <input type="text" id="lg-cm-new-city" placeholder="City name (e.g. Oakville)" class="regular-text" />
                <button class="button button-primary" id="lg-cm-add-city">+ Add</button>
            </div>
            <div class="lg-cm-loc-list" id="lg-cm-loc-list">
                <?php foreach ( $locations as $slug ) echo lg_cm_loc_row_html( $slug ); ?>
            </div>
            <div class="lg-cm-panel-footer">
                <button class="button button-primary" id="lg-cm-save-locations">Save locations</button>
                <span class="lg-cm-save-msg" id="lg-cm-loc-msg"></span>
            </div>
        </div>

        <!-- Selective Locations -->
        <div class="lg-cm-panel">
            <div class="lg-cm-panel-header">
                <div>
                    <h2>Selective locations</h2>
                    <p>Cities where JS redirects links to generic service pages (no dedicated city pages needed)</p>
                </div>
                <span class="lg-cm-badge lg-cm-badge-info" id="lg-cm-sel-badge"><?php echo count( $selective ); ?> locations</span>
            </div>
            <div class="lg-cm-add-row">
                <input type="text" id="lg-cm-new-selective" placeholder="City name (e.g. Ajax)" class="regular-text" />
                <button class="button button-primary" id="lg-cm-add-selective">+ Add</button>
            </div>
            <div class="lg-cm-loc-list" id="lg-cm-selective-list">
                <?php foreach ( $selective as $slug ) echo lg_cm_loc_row_html( $slug, 'selective' ); ?>
            </div>
            <div class="lg-cm-panel-footer">
                <button class="button button-primary" id="lg-cm-save-selective">Save selective locations</button>
                <span class="lg-cm-save-msg" id="lg-cm-sel-msg"></span>
            </div>
        </div>

        <!-- Settings -->
        <div class="lg-cm-panel">
            <div class="lg-cm-panel-header">
                <div><h2>Plugin settings</h2><p>Control plugin behaviour</p></div>
            </div>
            <form id="lg-cm-settings-form">
                <?php
                $toggles = [
                    'cookie_fallback'  => [ 'Read city from cookie on non-location pages',          'Enables menu rewriting on homepage, blog, About, etc.' ],
                    'generic_fallback' => [ 'Fallback to generic page when city page is missing',    'Prevents 404 — redirects to /service/ if /locations/city/service/ doesn\'t exist' ],
                    'show_city_in_btn' => [ 'Show saved city in "Find Your Location" button',        'Updates the button text on non-city pages using localStorage' ],
                    'debug_mode'       => [ 'Debug mode',                                             'Logs city detection and URL rewrites to the browser console' ],
                ];
                foreach ( $toggles as $name => [ $title, $desc ] ) : ?>
                <div class="lg-cm-toggle-row">
                    <div class="lg-cm-toggle-label">
                        <strong><?php echo esc_html( $title ); ?></strong>
                        <span><?php echo esc_html( $desc ); ?></span>
                    </div>
                    <label class="lg-cm-toggle">
                        <input type="checkbox" name="<?php echo esc_attr( $name ); ?>" <?php checked( $settings[ $name ], 1 ); ?> />
                        <span class="lg-cm-toggle-track"></span>
                    </label>
                </div>
                <?php endforeach; ?>
                <div class="lg-cm-panel-footer">
                    <button type="submit" class="button button-primary">Save settings</button>
                    <span class="lg-cm-save-msg" id="lg-cm-settings-msg"></span>
                </div>
            </form>
        </div>

    </div>
    <?php
}


/* HTML helpers */
function lg_cm_loc_row_html( $slug, $type = 'location' ) {
    $label = lg_cm_label( $slug );
    ob_start(); ?>
    <div class="lg-cm-loc-item" data-slug="<?php echo esc_attr( $slug ); ?>" data-type="<?php echo esc_attr( $type ); ?>">
        <span class="lg-cm-loc-dot"></span>
        <span class="lg-cm-loc-name"><?php echo esc_html( $label ); ?></span>
        <span class="lg-cm-loc-slug">/<?php echo esc_html( $slug ); ?>/</span>
        <div class="lg-cm-loc-actions">
            <?php if ( $type === 'location' ) : ?>
            <a href="<?php echo esc_url( home_url( '/locations/' . $slug . '/' ) ); ?>" target="_blank" class="button button-small" title="Preview">
                <span class="dashicons dashicons-external" style="font-size:14px;line-height:26px"></span>
            </a>
            <?php endif; ?>
            <button class="button button-small lg-cm-remove-loc" title="Remove">
                <span class="dashicons dashicons-trash" style="font-size:14px;line-height:26px;color:#b32d2e"></span>
            </button>
        </div>
    </div>
    <?php return ob_get_clean();
}

function lg_cm_service_block_html( $si, $service ) {
    ob_start(); ?>
    <div class="lg-cm-service-block" data-index="<?php echo (int) $si; ?>">
        <div class="lg-cm-service-header">
            <div class="lg-cm-service-header-left">
                <span class="dashicons dashicons-menu-alt2 lg-cm-drag-handle"></span>
                <div>
                    <input type="text" class="lg-cm-service-label" value="<?php echo esc_attr( $service['label'] ); ?>" placeholder="Service name" />
                    <code class="lg-cm-service-slug-display">/<?php echo esc_html( $service['slug'] ); ?>/</code>
                    <input type="hidden" class="lg-cm-service-slug" value="<?php echo esc_attr( $service['slug'] ); ?>" />
                </div>
            </div>
            <div class="lg-cm-service-header-right">
                <button class="button button-small lg-cm-toggle-subs">▾ Sub-services (<?php echo count( $service['subs'] ?? [] ); ?>)</button>
                <button class="button button-small lg-cm-remove-service lg-cm-btn-danger-sm">Remove</button>
            </div>
        </div>
        <div class="lg-cm-subs-wrap">
            <div class="lg-cm-subs-header">
                <span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">SUB-SERVICE SLUG</span>
                <span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">LABEL</span>
                <span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">TORONTO SLUG (if different)</span>
                <span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">OTHER CITIES SLUG (if different)</span>
                <span style="flex:2;font-size:11px;color:#6b7280;font-weight:600">GENERIC PAGE SLUG (if different)</span>
                <span style="flex:0 0 32px"></span>
            </div>
            <div class="lg-cm-subs-list">
                <?php foreach ( $service['subs'] ?? [] as $sub ) : ?>
                    <?php echo lg_cm_sub_row_html( $sub ); ?>
                <?php endforeach; ?>
            </div>
            <button class="button button-small lg-cm-add-sub" style="margin-top:8px">+ Add sub-service</button>
        </div>
    </div>
    <?php return ob_get_clean();
}

function lg_cm_sub_row_html( $sub = [] ) {
    ob_start(); ?>
    <div class="lg-cm-sub-row">
        <input type="text" class="lg-cm-sub-slug"         value="<?php echo esc_attr( $sub['slug']         ?? '' ); ?>" placeholder="e.g. installation" />
        <input type="text" class="lg-cm-sub-label"        value="<?php echo esc_attr( $sub['label']        ?? '' ); ?>" placeholder="Label" />
        <input type="text" class="lg-cm-sub-toronto"      value="<?php echo esc_attr( $sub['toronto_slug'] ?? '' ); ?>" placeholder="toronto-slug (blank = same)" />
        <input type="text" class="lg-cm-sub-other"        value="<?php echo esc_attr( $sub['other_slug']   ?? '' ); ?>" placeholder="other-slug (blank = same)" />
        <input type="text" class="lg-cm-sub-generic"      value="<?php echo esc_attr( $sub['generic_slug'] ?? '' ); ?>" placeholder="generic-slug (blank = same)" />
        <button class="button button-small lg-cm-remove-sub" title="Remove sub" style="flex:0 0 32px;padding:0;color:#b32d2e">✕</button>
    </div>
    <?php return ob_get_clean();
}
