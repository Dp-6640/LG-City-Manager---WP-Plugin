/**
 * LG City Manager — city-manager.js v2.1.0
 * - Saves city to localStorage + cookie
 * - Updates location button on non-city pages
 * - Rewrites generic service links → city-specific URLs (for full city pages)
 * - Rewrites selective location links → generic service URLs
 */
document.addEventListener("DOMContentLoaded", function () {

    var cfg                = window.lgCityManager || {};
    var debug              = cfg.debugMode === 1;
    var showBtn            = cfg.showCityInBtn !== 0;
    var validServices      = cfg.validServices      || [];
    var selectiveLocations = cfg.selectiveLocations || [];
    var fullLocations      = cfg.locations          || [];

    function log(msg) { if (debug) console.log('[LG City Manager] ' + msg); }

    /* ----------------------------------------------------------
     * 1. Detect city from URL and persist
     * ---------------------------------------------------------- */
    var urlMatch = window.location.pathname.match(/^\/locations\/([^\/]+)\//);

    if (urlMatch) {
        var city = urlMatch[1];
        try { localStorage.setItem('lg_city', city); } catch(e) {}
        document.cookie = 'lg_city=' + city + ';path=/;max-age=2592000;SameSite=Lax';
        log('City saved from URL: ' + city);
    }

    /* ----------------------------------------------------------
     * 2. On non-city pages — update location button + rewrite
     *    generic service links to city-specific URLs
     * ---------------------------------------------------------- */
    if (!urlMatch) {

        var savedCity = '';
        try { savedCity = localStorage.getItem('lg_city') || ''; } catch(e) {}

        // Fallback: read from cookie if localStorage is empty
        if (!savedCity) {
            var cookieMatch = document.cookie.match(/(?:^|;\s*)lg_city=([^;]+)/);
            if (cookieMatch) savedCity = cookieMatch[1];
        }

        if (savedCity) {

            /* 2a. Update location button text */
            if (showBtn) {
                var formatted = savedCity.replace(/-/g, ' ').replace(/\b\w/g, function(c){ return c.toUpperCase(); });
                var btn = document.getElementById('locationButton');
                if (btn) {
                    btn.innerHTML =
                        '<img src="https://staging.lghomecomfort.ca/wp-content/uploads/2026/03/Location-pin-new.svg"' +
                        ' alt="Location" style="width:16px;vertical-align:middle;margin-right:4px;">' + formatted;
                    log('Location button updated: ' + formatted);
                }
            }

            /* 2b. Only rewrite to city URLs for full location cities (not selective) */
            var isFullCity = fullLocations.indexOf(savedCity) !== -1;

            if (isFullCity && validServices.length > 0) {
                log('Rewriting generic service links to /locations/' + savedCity + '/...');

                document.querySelectorAll('a[href]').forEach(function(link) {
                    try {
                        var url   = new URL(link.href);
                        var parts = url.pathname.split('/').filter(Boolean);

                        // Skip links that already have /locations/ in them
                        if (parts[0] === 'locations') return;

                        // Skip non-service links (admin, wp-content, anchors, etc.)
                        if (!parts.length || parts[0].indexOf('wp-') === 0) return;
                        if (url.pathname === '/' || url.pathname === '') return;

                        // Build the service path from the link e.g. "furnace/installation"
                        var servicePath = parts.join('/');

                        // Check if this is a valid service path
                        if (validServices.indexOf(servicePath) !== -1) {
                            link.href = '/locations/' + savedCity + '/' + servicePath + '/';
                            log('Rewritten to city URL: ' + link.href);
                            return;
                        }

                        // Check parent-only match (e.g. /furnace/ or /heat-pumps/)
                        if (parts.length === 1) {
                            var parentSlug = parts[0];
                            // Check if any valid service starts with this parent
                            var hasService = validServices.some(function(s) {
                                return s.indexOf(parentSlug + '/') === 0;
                            });
                            if (hasService) {
                                link.href = '/locations/' + savedCity + '/' + parentSlug + '/';
                                log('Rewritten parent to city URL: ' + link.href);
                            }
                        }

                    } catch(e) {
                        log('Error processing link: ' + e.message);
                    }
                });
            }
        }
    }

    /* ----------------------------------------------------------
     * 3. Rewrite selective location links → generic service URLs
     *    Only applies to cities in selectiveLocations list
     * ---------------------------------------------------------- */
    if (selectiveLocations.length === 0 || validServices.length === 0) return;

    document.querySelectorAll("a[href*='/locations/']").forEach(function(link) {
        try {
            var url   = new URL(link.href);
            var parts = url.pathname.split('/').filter(Boolean);

            if (parts[0] !== 'locations' || parts.length < 3) return;

            var citySlug = parts[1].toLowerCase();
            if (selectiveLocations.indexOf(citySlug) === -1) return;

            var serviceParts = parts.slice(2);
            var newPath      = serviceParts.join('/');

            // Already a valid service path — rewrite to generic
            if (validServices.indexOf(newPath) !== -1) {
                link.href = '/' + newPath + '/';
                log('Selective rewritten (exact): ' + link.href);
                return;
            }

            // Normalize last segment (remove -installation/-repair/-maintenance suffix)
            if (serviceParts.length >= 2) {
                serviceParts[1] = serviceParts[1].replace(/-(installation|repair|maintenance)$/, '');
                var normalized = serviceParts.join('/');
                if (validServices.indexOf(normalized) !== -1) {
                    link.href = '/' + normalized + '/';
                    log('Selective rewritten (normalized): ' + link.href);
                    return;
                }
            }

            // Special case: reverse-osmosis variants
            if (newPath.indexOf('water-purification/reverse-osmosis') === 0) {
                link.href = '/water-purification/reverse-osmosis-system/';
                log('Selective rewritten (reverse-osmosis): ' + link.href);
            }

        } catch(e) {
            log('Error processing link: ' + e.message);
        }
    });

});
